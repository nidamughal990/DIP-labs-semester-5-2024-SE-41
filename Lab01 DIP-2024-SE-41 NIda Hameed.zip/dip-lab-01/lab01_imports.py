# 01import libraries
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

print("NumPy:", np.__version__)
print("Pillow:", Image.__version__ if hasattr(Image, "__version__") else "Imported successfully")
print("Matplotlib:", plt.matplotlib.__version__)

print("All libraries verified successfully!")
